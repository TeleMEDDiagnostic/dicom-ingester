#! /usr/bin/env python
# -*- coding utf utf-8 -*-

import pydicom
import numpy
import time
import json
import cv2
import numpngw
import os
import skvideo.io
import random

def regionFlags(element, reference):
  flags = []

  for position in range(len(reference)):
    ''' Create the mask to be used to isolate a specific flag
        Example: 
        numberOfBits = 3
        mask = sum([2 ** i for i in range(numberOfBits)])
        'mask' would hold the value 7, which is 0b111.
    '''
    mask = sum([2 ** i for i in range(reference[position]["numberOfBits"])])

    #  'mask & element' will give as the index of the item that we want from the array of values
    flags.append(reference[position]["flag"][element & mask])
    element = element >> reference[position]["numberOfBits"]

  return flags

def processImageRegion(imageRegion):
  ingesterPath = os.path.dirname(os.path.realpath(__file__))
  referenceTable = {"regions": {}}
  referencePixel = {}
  regionX1 = 0
  regionY1 = 0

  ir = {"boundingBox": {}}
  try:
    with open(os.path.join(ingesterPath, "normalizationTable.json") ,'r') as rf:
        referenceTable = json.load(rf)
        rf.close()
  except FileNotFoundError:
    print("normalizationTable.json is missing")
  
  for element in imageRegion:
    if element.keyword in referenceTable["regions"]:
      key = referenceTable["regions"][element.keyword]["key"]
      if "values" in referenceTable["regions"][element.keyword]:
        if element.keyword is "RegionFlags":
          '''
            NOTE(Josue): When processing flags, for 'priority' (bit 0):
              0 = Region pixels are high priority
              1 = Region pixels are low priority
              https://dicom.innolitics.com/ciods/us-multi-frame-image/us-region-calibration/00186011/00186016
          '''
          flags = regionFlags(element.value, referenceTable["regions"]["RegionFlags"]["values"])
          for position in range(len(referenceTable["regions"]["RegionFlags"]["values"])):
            ir[referenceTable["regions"]["RegionFlags"]["values"][position]["key"]] = flags[position]
        else:
          ir[key] = referenceTable["regions"][element.keyword]["values"][element.value]
      else:
        if element.keyword in ["RegionLocationMinX0", "RegionLocationMinY0", "RegionLocationMaxX1", "RegionLocationMaxY1"]:
          # We store RegionLocationMax{X1, Y1} to calculate width and height later
          if element.keyword is "RegionLocationMaxX1":
            regionX1 = element.value
          elif element.keyword is "RegionLocationMaxY1":
            regionY1 = element.value
          else:
            ir["boundingBox"][key] = element.value
        elif element.keyword in ["ReferencePixelX0", "ReferencePixelY0"]:
          referencePixel[key] = element.value
        else:
          ir[key] = element.value

    else:
      key = element.keyword
      ir[key] = element.value
    
    if bool(referencePixel):
      ir["reference"] = referencePixel

  # Calculate width and height
  ir["boundingBox"]["width"] = regionX1 - ir["boundingBox"]["x"]
  ir["boundingBox"]["height"] = regionY1 - ir["boundingBox"]["y"]

  return ir


def createTiledImage(arrayOfFrames, resolution, numberOfTiles):
    tiledImage = []
    dimensions = []
    extraTiles = 0

    oneSideLength = 1
    while numberOfTiles > (oneSideLength * oneSideLength):
        oneSideLength += 1


    # Check what dimensions are optimal for a good looking square shaped image
    if oneSideLength * (oneSideLength - 2) > numberOfTiles and oneSideLength * (oneSideLength - 2) - numberOfTiles < oneSideLength * (oneSideLength - 1) - numberOfTiles:
        dimensions, extraTiles = [oneSideLength, oneSideLength - 2], oneSideLength * (oneSideLength - 2) - numberOfTiles

    elif oneSideLength * (oneSideLength - 1) > numberOfTiles and oneSideLength * (oneSideLength - 1) - numberOfTiles < oneSideLength * oneSideLength - numberOfTiles:
        dimensions, extraTiles = [oneSideLength, oneSideLength - 1], oneSideLength * (oneSideLength - 1) - numberOfTiles

    else:
        dimensions, extraTiles = [oneSideLength, oneSideLength], oneSideLength * oneSideLength - numberOfTiles
    

    # Filling up the last row with empty thumbnails if needed
    for i in range(extraTiles):
        arrayOfFrames.append(numpy.zeros((resolution[0], resolution[1], 3), dtype=int))

    for y in range(dimensions[1]):
        for k in range(resolution[0]):
            row = numpy.array(arrayOfFrames[y * dimensions[0]][k])
            for x in range(1, dimensions[0]):
                row = numpy.concatenate((row, arrayOfFrames[y * dimensions[0] + x][k]), axis=0)

            tiledImage.append(row)

    return numpy.array(tiledImage, dtype = numpy.uint8)


def generateInfoFile(dicomInfo, folder, scaleFactor = 0):
    obj = {}
    print("Generating info file")
    for baseKey, baseValue in dicomInfo.items():
        obj[baseKey] = {}
        for key, val in baseValue.items():
            if val is not None:
              if isinstance(val, list):
                obj[baseKey][key] = val
              else:
                if isinstance(val, int) | isinstance(val, str):
                    obj[baseKey][key] = val
                else:
                    obj[baseKey][key] = EX.toStr(val.value)

    if scaleFactor != 0:
        obj["Image"]["scaledRows"] =  str(int(dicomInfo["Image"]["rows"].value * scaleFactor))
        obj["Image"]["scaledColumns"] =  str(int(dicomInfo["Image"]["columns"].value * scaleFactor))
    
    if dicomInfo["Image"]["numberOfFrames"] is not None and dicomInfo["Image"]["recommendedDisplayFrameRate"] is None:
        # default value arbitrarily set to 29
        obj["Image"]["recommendedDisplayFrameRate"] = "29"
    
    if dicomInfo["Image"]["samplesPerPixel"].value == 3:
      obj["Image"]["isColor"] = True
    else:
      obj["Image"]["isColor"] = False

    with open(folder + "/info.json", 'w') as fp:
        json.dump(obj, fp)
        fp.close()

def scaleImage(image, ratio):
    return cv2.resize(image, dsize=(int(ratio * len(image[0])), int(ratio * len(image))), interpolation = cv2.INTER_LINEAR)

def getIndex(comment):
  xy = 0
  if comment is not None:
      splited = EX.toStr(comment.value).split(':')
      for item in splited:
        print(item)
        if 'RowNumber' in item:
          rowSplited = item.split('=')
          xy +=  int(rowSplited[1])
        if 'ColNumber' in item:
          colSplited = item.split('=')
          xy += 10 * int(colSplited[1])
      return xy
  else:
      return random.randint(800, 999)

def getIndex(dataSet):
  xy = 0
  stage = 0
  tag = dataSet.get(pydicom.tag.Tag(0x0008,0x2120))
  if tag is not None:
   # numberOfStages =  dataSet.get(pydicom.tag.Tag(0x0008,0x2124)).value
    stageNumber =  returnElementNotNull(dataSet.get(pydicom.tag.Tag(0x0008,0x2122)))
    viewNumber = returnElementNotNull(dataSet.get(pydicom.tag.Tag(0x0008,0x2128)))
    stageName =  EX.toStr(returnElementNotNull(dataSet.get(pydicom.tag.Tag(0x0008,0x2120)))).upper()

    if stageName == "REST":
      stage = 1
    if stageName == "POST" or stageName == "PEAK":
      stage = 2
    if stageName == "RECOVERY":
      stage = 3 

    #xy = (numberOfStages * 1000) + (stageNumber * 100) + (viewNumber * 10) + stage

    xy = (viewNumber * 100) + (stageNumber * 10) + stage
    return xy
     
  else:
      return random.randint(8000, 9999)

def returnElementNotNull(elem):
  if elem is not None:
    return elem
  return EX.toStr('-')





def imageToPng(dataSet, obj):
    print("Processing Ultrasound Image")   
    dicomData = { "Patient" :
                        {"PatientName" : dataSet.get(pydicom.tag.Tag(0x0010, 0x0010)),                 
                        "PatientID" : dataSet.get(pydicom.tag.Tag(0x0010, 0x0020)), 
                        "PatientDOB" : dataSet.get(pydicom.tag.Tag(0x0010, 0x0030)),
                        "PatientGender" : dataSet.get(pydicom.tag.Tag(0x0010, 0x0040)),
                        "PatientEthnic" : dataSet.get(pydicom.tag.Tag(0x0010, 0x2160)),
                        "PatientWeight" : dataSet.get(pydicom.tag.Tag(0x0010, 0x1030)),
                        "PatientHeight" : dataSet.get(pydicom.tag.Tag(0x0010, 0x1020))
                        },
                    "Device" :
                        {"DeviceName" : dataSet.get(pydicom.tag.Tag(0x0008, 0x1090)),
                        "DeviceModel" : dataSet.get(pydicom.tag.Tag(0x0018, 0x1020)),
                        "DeviceSerialNumber" : dataSet.get(pydicom.tag.Tag(0x0018, 0x1000)),
                        "VendorName" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0070))
                        },
                    "Test" :
                        {"TestModality" : dataSet.get(pydicom.tag.Tag(0x0008,0x0060)),
                        "TestDescription" : dataSet.get(pydicom.tag.Tag(0x0008,0x1030)),
                        "TestDate" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0020)),
                        "TestTime" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0030)),
                        "TimezoneOffset" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0201)),
                        "referringPhysician" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0090)),
                        "StudyInstanceUID" : dataSet.get(pydicom.tag.Tag(0x0020, 0x000d)),
                        "SeriesInstanceUID" : dataSet.get(pydicom.tag.Tag(0x0020, 0x000e)),
                        "SOPInstanceUID" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0018))
                        },
                    "Image" :
                        {"samplesPerPixel" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0002)),
                        "rows" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0010)),
                        "columns" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0011)),
                        "bitsAllocated" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0100)),
                        "compressionMethod" : dataSet.get(pydicom.tag.Tag(0x0028, 0x2114)),
                        "numberOfFrames" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0008)),
                        "imageType" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0008)),
                        "recommendedDisplayFrameRate" : dataSet.get(pydicom.tag.Tag(0x0008, 0x2144)),    
                        "photometricInterpretation" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0004)),
                        "pixelRepresentation" : dataSet.get(pydicom.tag.Tag(0x0028, 0x0103)),
                        "stageName" : returnElementNotNull(dataSet.get(pydicom.tag.Tag(0x0008, 0x2120))),
                        "viewName" : returnElementNotNull(dataSet.get(pydicom.tag.Tag(0x0008, 0x2127))),
                        "index" : 0, #getIndex(dataSet),
                        "comment" : returnElementNotNull(dataSet.get(pydicom.tag.Tag(0x0020, 0x4000))),
                        "Date" : dataSet.get(pydicom.tag.Tag(0x0008, 0x0023)),
                        "Time" : dataSet.get(pydicom.tag.Tag(0x0008,0x0033))
                        }
                }

    imageRegionData = dataSet.get(pydicom.tag.Tag(0x0018,0x6011))
    regions = []
    if imageRegionData is not None:
      for imageRegion in imageRegionData.value:
        regions.append(processImageRegion(imageRegion))

    dicomData["Image"]["regions"] = regions
    patientDir = obj['folderForPatients'] + "/" + EX.toStr(dicomData["Patient"]["PatientID"].value) + "/" + EX.toStr(dicomData["Test"]["StudyInstanceUID"].value) + "/" + EX.toStr(dicomData["Test"]["SeriesInstanceUID"].value) + "/" + EX.toStr(dicomData["Test"]["SOPInstanceUID"].value)
    if not os.path.exists(patientDir):
        os.makedirs(patientDir)

    print(dataSet.get(pydicom.tag.Tag(0x0028, 0x0004)).value)
    colorPlate = 0;
    if(dataSet.get(pydicom.tag.Tag(0x0028, 0x0004)).value == 'YBR_FULL'):
      colorPlate = cv2.COLOR_YUV2RGB
    else:
      colorPlate = cv2.COLOR_RGB2BGR





    # Single-frame
    if dicomData["Image"]["numberOfFrames"] is None:
        print("Single-frame")
        start = time.time()
        #For YBR_Full = cv2.COLOR_YUV2RGB
       
        cv2.imwrite(
                patientDir + "/image.png", cv2.cvtColor(dataSet.pixel_array, colorPlate), [cv2.IMWRITE_PNG_COMPRESSION, 5])
        print(time.time() - start)

        print("Done processing image")
        generateInfoFile(dicomData, patientDir)

    # Multi-frame
    else:
        print("Multi-frame")
        print(len(dataSet.PixelData))
        newArray = []
        for i in range(dicomData["Image"]["numberOfFrames"].value):
            newArray.append(scaleImage(dataSet.pixel_array[i], obj['scaleFactor']))

        numpyFrames = numpy.array(newArray, dtype = numpy.uint8)
        
        if dicomData["Image"]["recommendedDisplayFrameRate"] is not None:
            delayInMl = 1000 / dicomData["Image"]["recommendedDisplayFrameRate"].value
        else:
            delayInMl = 50

        # generate preview

        cv2.imwrite(
                patientDir + "/image.png", cv2.cvtColor(dataSet.pixel_array[0], colorPlate), [cv2.IMWRITE_PNG_COMPRESSION, 5])

        # generate MP4s
        print("The delay is " + str(delayInMl))
        start = time.time()

        # ffmpeg args from https://gist.github.com/docPhil99/a612c355cd31e69a0d3a6d2f87bfde8b
        # writer = skvideo.io.FFmpegWriter(patientDir + "/image.mp4", outputdict={
        #     '-vcodec': 'libx264',  # use the h.264 codec
        #     '-pix_fmt': 'yuv420p', # use a lower-bitrate encoding to support Firefox
        #     '-crf': '15',          # constant rate factor between 0 (lossless) and 52 (worst)
        #     '-preset':'veryslow'   # the slower the better compression, in princple, try 
        #                            # other options see https://trac.ffmpeg.org/wiki/Encode/H.264
        # })

        writer = skvideo.io.FFmpegWriter(patientDir + "/image.mp4", outputdict={
            '-vcodec': 'libx264',  # use the h.264 codec
            '-pix_fmt': 'yuv420p', # use a lower-bitrate encoding to support Firefox
            '-crf': '15',          # constant rate factor between 0 (lossless) and 52 (worst)
            '-preset':'veryslow'   # the slower the better compression, in princple, try 
                                   # other options see https://trac.ffmpeg.org/wiki/Encode/H.264
        })

        for frame in dataSet.pixel_array:
            if(dataSet.get(pydicom.tag.Tag(0x0028, 0x0004)).value == 'YBR_FULL'):
              writer.writeFrame(cv2.cvtColor(frame, colorPlate))
            else:
              writer.writeFrame(frame)

        writer.close()

        print("Generated MP4 in " + str(time.time() - start))

        # generate thumbnails
        start = time.time()
        cv2.imwrite(
                patientDir + "/thumbnails.png", cv2.UMat(
                    cv2.cvtColor(createTiledImage(newArray, [int(dicomData["Image"]["rows"].value  * obj['scaleFactor']), int(dicomData["Image"]["columns"].value * obj['scaleFactor'])], dicomData["Image"]["numberOfFrames"].value),colorPlate)))
        print(time.time() - start)        
        print("Done processing image")


        generateInfoFile(dicomData, patientDir, obj["scaleFactor"])


if __name__ == '__main__':

    import sys, os
    import xmlTools as EX

    if len(sys.argv) < 2:
        sys.exit("Format: python3 inputParser.py input.dcm")
    else:
        try:
            dataSet = pydicom.dcmread(sys.argv[1])

        except pydicom.errors.InvalidDicomError:
            print("Dicom file '" + sys.argv[1] + "' is missing metadata information")

        except FileNotFoundError:
            print("File '" + sys.argv[1] + "' not found")

        else:
            imageToPng(dataSet)

else:
    import parsers.xmlTools as EX
